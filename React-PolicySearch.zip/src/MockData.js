export let policyStatusList = [
    {
        name: 'In Effect',
        code: 'In Effect'
    },
    {
        name: 'Cancel',
        code: 'Cancel'
    },
];
export let policyPlanList = [
    {
        name: 'Home'
    },
    {
        name: 'Appartment'
    },
    {
        name: 'Villa'
    },
];
export let policyList = [
    {
        policyId: "P1536",
        policyType: "Home",
        policyPropertyValue: 3000000,
        policyStartDate: "12/05/2016",
        policyEndDate: "12/05/2016",
        policyStatus: "In Effect"
    },
    {
        policyId: "P1537",
        policyType: "Appartment",
        policyPropertyValue: 5000000,
        policyStartDate: "12/05/2016",
        policyEndDate: "12/05/2016",
        policyStatus: "In Effect"
    },
    {
        policyId: "P1538",
        policyType: "Home",
        policyPropertyValue: 5000000,
        policyStartDate: "12/05/2016",
        policyEndDate: "12/05/2016",
        policyStatus: "Cancel"
    },
    {
        policyId: "P1539",
        policyType: "Appartment",
        policyPropertyValue: 5000000,
        policyStartDate: "12/05/2016",
        policyEndDate: "12/05/2016",
        policyStatus: "Cancel"
    },
    {
        policyId: "P1540",
        policyType: "Villa",
        policyPropertyValue: 5000000,
        policyStartDate: "12/05/2016",
        policyEndDate: "12/05/2016",
        policyStatus: "Cancel"
    },
    {
        policyId: "P1541",
        policyType: "Villa",
        policyPropertyValue: 5000000,
        policyStartDate: "12/05/2016",
        policyEndDate: "12/05/2016",
        policyStatus: "In Effect"
    },
];
