var Express = require('express')
var Mongoose = require('mongoose')
var BodyParser = require('body-parser')

var dburl = "mongodb://testuser:test12345@ds045704.mlab.com:45704/hcldatabase"

Mongoose.connect(dburl, function(err){
    if(err){
        console.log("error in connecting to db", err)
    }
    else{
        console.log("Connected to database")
    }
})

var Port = process.env.PORT || 8000


var server = Express()
server.use(Express.static(__dirname+'/frontend'))
server.use(BodyParser.json())

server.get('/', function(req,res){
     res.sendFile(__dirname+'/frontend/index.html')
})

server.use('/movie', require('./moviefolder'))

server.listen(Port, function(){
    console.log("Server is listening on", Port)
})
